import Register from "./Register"
import Login from "./Login"
import Home from "./Home"
import Profile from "./Profile/Profile"

export{Register, Login, Home, Profile}