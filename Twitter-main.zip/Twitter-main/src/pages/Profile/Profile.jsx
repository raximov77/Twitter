import React from 'react'

function profile() {
  return (
    <div>profile</div>
  )
}

export default profile