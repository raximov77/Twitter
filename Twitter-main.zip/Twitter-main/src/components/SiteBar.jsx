import React from 'react'

function SiteBar() {
  return (
    <div className='w-[25%]'>SiteBar</div>
  )
}

export default SiteBar